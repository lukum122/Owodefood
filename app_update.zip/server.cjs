var __create = Object.create;
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __getProtoOf = Object.getPrototypeOf;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toESM = (mod, isNodeMode, target) => (target = mod != null ? __create(__getProtoOf(mod)) : {}, __copyProps(
  // If the importer is in node compatibility mode or this is not an ESM
  // file that has been converted to a CommonJS file using a Babel-
  // compatible transform (i.e. "__esModule" has not been set), then set
  // "default" to the CommonJS "module.exports" for node compatibility.
  isNodeMode || !mod || !mod.__esModule ? __defProp(target, "default", { value: mod, enumerable: true }) : target,
  mod
));

// server.ts
var import_config = require("dotenv/config");
var import_express = __toESM(require("express"), 1);
var import_path2 = __toESM(require("path"), 1);
var import_vite = require("vite");

// src/db/index.ts
var import_node_postgres = require("drizzle-orm/node-postgres");
var import_migrator = require("drizzle-orm/node-postgres/migrator");
var import_pg = __toESM(require("pg"), 1);
var import_path = __toESM(require("path"), 1);

// src/db/schema.ts
var schema_exports = {};
__export(schema_exports, {
  addresses: () => addresses,
  appNotifications: () => appNotifications,
  categories: () => categories,
  employees: () => employees,
  extremeLocationTiers: () => extremeLocationTiers,
  extremeLocations: () => extremeLocations,
  orderItems: () => orderItems,
  orders: () => orders,
  paymentGateways: () => paymentGateways,
  products: () => products,
  pushSubscriptions: () => pushSubscriptions,
  receiptPickupOrders: () => receiptPickupOrders,
  reviews: () => reviews,
  riders: () => riders,
  systemSettings: () => systemSettings,
  userSavedAddresses: () => userSavedAddresses,
  users: () => users,
  vendors: () => vendors,
  walletTransactions: () => walletTransactions
});
var import_pg_core = require("drizzle-orm/pg-core");
var users = (0, import_pg_core.pgTable)("users", {
  id: (0, import_pg_core.text)("id").primaryKey(),
  // Firebase Auth UID
  email: (0, import_pg_core.text)("email").notNull(),
  name: (0, import_pg_core.text)("name").notNull(),
  phone: (0, import_pg_core.text)("phone").notNull(),
  role: (0, import_pg_core.text)("role").notNull(),
  // customer | vendor | rider | admin | employee
  gender: (0, import_pg_core.text)("gender"),
  createdAt: (0, import_pg_core.text)("created_at").notNull(),
  pin: (0, import_pg_core.text)("pin"),
  roles: (0, import_pg_core.jsonb)("roles")
});
var vendors = (0, import_pg_core.pgTable)("vendors", {
  id: (0, import_pg_core.text)("id").primaryKey(),
  userId: (0, import_pg_core.text)("user_id").references(() => users.id),
  name: (0, import_pg_core.text)("name").notNull(),
  description: (0, import_pg_core.text)("description").notNull(),
  cuisine: (0, import_pg_core.text)("cuisine").notNull(),
  image: (0, import_pg_core.text)("image").notNull(),
  rating: (0, import_pg_core.doublePrecision)("rating").notNull().default(5),
  address: (0, import_pg_core.text)("address").notNull(),
  status: (0, import_pg_core.text)("status").notNull(),
  // pending | approved | suspended
  createdAt: (0, import_pg_core.text)("created_at").notNull(),
  openingTime: (0, import_pg_core.text)("opening_time"),
  closingTime: (0, import_pg_core.text)("closing_time"),
  openingDays: (0, import_pg_core.jsonb)("opening_days"),
  coverImage: (0, import_pg_core.text)("cover_image"),
  category: (0, import_pg_core.text)("category"),
  prepTime: (0, import_pg_core.integer)("prep_time"),
  deliveryFee: (0, import_pg_core.integer)("delivery_fee"),
  serviceFee: (0, import_pg_core.integer)("service_fee"),
  serviceFeeType: (0, import_pg_core.text)("service_fee_type"),
  // flat | percentage
  serviceFeeValue: (0, import_pg_core.integer)("service_fee_value"),
  commissionType: (0, import_pg_core.text)("commission_type"),
  // flat | percentage
  commissionValue: (0, import_pg_core.integer)("commission_value"),
  freeDelivery: (0, import_pg_core.boolean)("free_delivery").default(false)
});
var products = (0, import_pg_core.pgTable)("products", {
  id: (0, import_pg_core.text)("id").primaryKey(),
  vendorId: (0, import_pg_core.text)("vendor_id").references(() => vendors.id).notNull(),
  name: (0, import_pg_core.text)("name").notNull(),
  description: (0, import_pg_core.text)("description").notNull(),
  price: (0, import_pg_core.integer)("price").notNull(),
  image: (0, import_pg_core.text)("image").notNull(),
  category: (0, import_pg_core.text)("category").notNull(),
  isAvailable: (0, import_pg_core.boolean)("is_available").notNull().default(true),
  createdAt: (0, import_pg_core.text)("created_at").notNull(),
  addons: (0, import_pg_core.jsonb)("addons"),
  // stores array of Addon objects
  maxAddons: (0, import_pg_core.integer)("max_addons"),
  addonGroups: (0, import_pg_core.jsonb)("addon_groups")
  // stores array of AddonGroup objects
});
var orders = (0, import_pg_core.pgTable)("orders", {
  id: (0, import_pg_core.text)("id").primaryKey(),
  customerId: (0, import_pg_core.text)("customer_id").references(() => users.id).notNull(),
  customerName: (0, import_pg_core.text)("customer_name").notNull(),
  customerPhone: (0, import_pg_core.text)("customer_phone").notNull(),
  vendorId: (0, import_pg_core.text)("vendor_id").references(() => vendors.id).notNull(),
  vendorName: (0, import_pg_core.text)("vendor_name").notNull(),
  riderId: (0, import_pg_core.text)("rider_id"),
  riderName: (0, import_pg_core.text)("rider_name"),
  status: (0, import_pg_core.text)("status").notNull(),
  // pending | accepted | preparing | ready | out_for_delivery | delivered | cancelled
  totalAmount: (0, import_pg_core.integer)("total_amount").notNull(),
  deliveryAddress: (0, import_pg_core.text)("delivery_address").notNull(),
  paymentMethod: (0, import_pg_core.text)("payment_method").notNull(),
  createdAt: (0, import_pg_core.text)("created_at").notNull(),
  serviceFee: (0, import_pg_core.integer)("service_fee"),
  deliveryFee: (0, import_pg_core.integer)("delivery_fee"),
  tax: (0, import_pg_core.integer)("tax")
});
var orderItems = (0, import_pg_core.pgTable)("order_items", {
  id: (0, import_pg_core.text)("id").primaryKey(),
  orderId: (0, import_pg_core.text)("order_id").references(() => orders.id).notNull(),
  productId: (0, import_pg_core.text)("product_id").notNull(),
  name: (0, import_pg_core.text)("name").notNull(),
  price: (0, import_pg_core.integer)("price").notNull(),
  quantity: (0, import_pg_core.integer)("quantity").notNull()
});
var riders = (0, import_pg_core.pgTable)("riders", {
  id: (0, import_pg_core.text)("id").primaryKey(),
  userId: (0, import_pg_core.text)("user_id").references(() => users.id),
  name: (0, import_pg_core.text)("name").notNull(),
  phone: (0, import_pg_core.text)("phone").notNull(),
  vehicleType: (0, import_pg_core.text)("vehicle_type").notNull(),
  // bicycle | motorcycle | car
  status: (0, import_pg_core.text)("status").notNull(),
  // pending | approved | suspended
  isAvailable: (0, import_pg_core.boolean)("is_available").notNull().default(true),
  createdAt: (0, import_pg_core.text)("created_at").notNull()
});
var addresses = (0, import_pg_core.pgTable)("addresses", {
  id: (0, import_pg_core.text)("id").primaryKey(),
  userId: (0, import_pg_core.text)("user_id").references(() => users.id).notNull(),
  title: (0, import_pg_core.text)("title").notNull(),
  address: (0, import_pg_core.text)("address").notNull()
});
var categories = (0, import_pg_core.pgTable)("categories", {
  id: (0, import_pg_core.text)("id").primaryKey(),
  name: (0, import_pg_core.text)("name").notNull(),
  icon: (0, import_pg_core.text)("icon").notNull()
});
var paymentGateways = (0, import_pg_core.pgTable)("payment_gateways", {
  id: (0, import_pg_core.text)("id").primaryKey(),
  name: (0, import_pg_core.text)("name").notNull(),
  desc: (0, import_pg_core.text)("desc").notNull(),
  isEnabled: (0, import_pg_core.boolean)("is_enabled").notNull().default(true),
  apiKey: (0, import_pg_core.text)("api_key"),
  secretKey: (0, import_pg_core.text)("secret_key"),
  contractCode: (0, import_pg_core.text)("contract_code"),
  bankName: (0, import_pg_core.text)("bank_name"),
  accountNumber: (0, import_pg_core.text)("account_number"),
  accountName: (0, import_pg_core.text)("account_name"),
  isActive: (0, import_pg_core.boolean)("is_active").default(false)
});
var userSavedAddresses = (0, import_pg_core.pgTable)("user_saved_addresses", {
  id: (0, import_pg_core.text)("id").primaryKey(),
  userId: (0, import_pg_core.text)("user_id").references(() => users.id).notNull(),
  streetAddress: (0, import_pg_core.text)("street_address").notNull(),
  district: (0, import_pg_core.text)("district").notNull(),
  landmarkNote: (0, import_pg_core.text)("landmark_note").notNull()
});
var extremeLocationTiers = (0, import_pg_core.pgTable)("extreme_location_tiers", {
  id: (0, import_pg_core.text)("id").primaryKey(),
  name: (0, import_pg_core.text)("name").notNull(),
  surcharge: (0, import_pg_core.integer)("surcharge").notNull()
});
var extremeLocations = (0, import_pg_core.pgTable)("extreme_locations", {
  id: (0, import_pg_core.text)("id").primaryKey(),
  name: (0, import_pg_core.text)("name").notNull(),
  tierId: (0, import_pg_core.text)("tier_id").references(() => extremeLocationTiers.id).notNull()
});
var employees = (0, import_pg_core.pgTable)("employees", {
  id: (0, import_pg_core.text)("id").primaryKey(),
  name: (0, import_pg_core.text)("name").notNull(),
  email: (0, import_pg_core.text)("email").notNull(),
  phone: (0, import_pg_core.text)("phone").notNull(),
  department: (0, import_pg_core.text)("department").notNull(),
  // support | dispatcher | finance | manager | admin
  status: (0, import_pg_core.text)("status").notNull(),
  // active | inactive
  permissions: (0, import_pg_core.jsonb)("permissions").notNull(),
  // array of strings
  createdAt: (0, import_pg_core.text)("created_at").notNull()
});
var systemSettings = (0, import_pg_core.pgTable)("system_settings", {
  key: (0, import_pg_core.text)("key").primaryKey(),
  value: (0, import_pg_core.text)("value").notNull()
});
var reviews = (0, import_pg_core.pgTable)("reviews", {
  id: (0, import_pg_core.text)("id").primaryKey(),
  vendorId: (0, import_pg_core.text)("vendor_id").references(() => vendors.id).notNull(),
  customerId: (0, import_pg_core.text)("customer_id").references(() => users.id).notNull(),
  author: (0, import_pg_core.text)("author").notNull(),
  rating: (0, import_pg_core.integer)("rating").notNull(),
  comment: (0, import_pg_core.text)("comment").notNull(),
  createdAt: (0, import_pg_core.text)("created_at").notNull()
});
var walletTransactions = (0, import_pg_core.pgTable)("wallet_transactions", {
  id: (0, import_pg_core.text)("id").primaryKey(),
  userId: (0, import_pg_core.text)("user_id").references(() => users.id).notNull(),
  userName: (0, import_pg_core.text)("user_name").notNull(),
  amount: (0, import_pg_core.integer)("amount").notNull(),
  type: (0, import_pg_core.text)("type").notNull(),
  // deposit | purchase | refund | adjustment
  note: (0, import_pg_core.text)("note"),
  createdAt: (0, import_pg_core.text)("created_at").notNull(),
  status: (0, import_pg_core.text)("status"),
  // approved | pending | declined
  gateway: (0, import_pg_core.text)("gateway"),
  // bank_transfer | monnify | paystack
  reference: (0, import_pg_core.text)("reference")
});
var appNotifications = (0, import_pg_core.pgTable)("app_notifications", {
  id: (0, import_pg_core.text)("id").primaryKey(),
  userId: (0, import_pg_core.text)("user_id").notNull(),
  title: (0, import_pg_core.text)("title").notNull(),
  message: (0, import_pg_core.text)("message").notNull(),
  type: (0, import_pg_core.text)("type").notNull(),
  // order | wallet | system | delivery
  read: (0, import_pg_core.boolean)("read").notNull().default(false),
  createdAt: (0, import_pg_core.text)("created_at").notNull(),
  relatedId: (0, import_pg_core.text)("related_id")
});
var receiptPickupOrders = (0, import_pg_core.pgTable)("receipt_pickup_orders", {
  id: (0, import_pg_core.text)("id").primaryKey(),
  customerId: (0, import_pg_core.text)("customer_id").references(() => users.id).notNull(),
  customerName: (0, import_pg_core.text)("customer_name").notNull(),
  customerPhone: (0, import_pg_core.text)("customer_phone").notNull(),
  vendorId: (0, import_pg_core.text)("vendor_id").references(() => vendors.id).notNull(),
  vendorName: (0, import_pg_core.text)("vendor_name").notNull(),
  vendorAddress: (0, import_pg_core.text)("vendor_address").notNull(),
  deliveryAddress: (0, import_pg_core.text)("delivery_address").notNull(),
  receiptImageOrQr: (0, import_pg_core.text)("receipt_image_or_qr").notNull(),
  receiptNote: (0, import_pg_core.text)("receipt_note"),
  deliveryFee: (0, import_pg_core.integer)("delivery_fee").notNull(),
  riderId: (0, import_pg_core.text)("rider_id"),
  riderName: (0, import_pg_core.text)("rider_name"),
  status: (0, import_pg_core.text)("status").notNull(),
  // pending | accepted | picked_up | delivered | cancelled
  paymentMethod: (0, import_pg_core.text)("payment_method").notNull(),
  paymentStatus: (0, import_pg_core.text)("payment_status").notNull(),
  // paid | unpaid
  serviceFee: (0, import_pg_core.integer)("service_fee"),
  totalAmount: (0, import_pg_core.integer)("total_amount"),
  createdAt: (0, import_pg_core.text)("created_at").notNull()
});
var pushSubscriptions = (0, import_pg_core.pgTable)("push_subscriptions", {
  id: (0, import_pg_core.text)("id").primaryKey(),
  userId: (0, import_pg_core.text)("user_id").notNull(),
  endpoint: (0, import_pg_core.text)("endpoint").notNull(),
  p256dh: (0, import_pg_core.text)("p256dh").notNull(),
  auth: (0, import_pg_core.text)("auth").notNull(),
  createdAt: (0, import_pg_core.text)("created_at").notNull()
});

// src/db/index.ts
var { Pool } = import_pg.default;
var createPool = () => {
  if (process.env.SQL_HOST) {
    return new Pool({
      host: process.env.SQL_HOST,
      user: process.env.SQL_USER,
      password: process.env.SQL_PASSWORD,
      database: process.env.SQL_DB_NAME,
      port: process.env.SQL_PORT ? Number(process.env.SQL_PORT) : 5432,
      max: 10,
      idleTimeoutMillis: 1e4,
      connectionTimeoutMillis: 1e4,
      keepAlive: true,
      keepAliveInitialDelayMillis: 1e4
    });
  }
  if (process.env.DATABASE_URL) {
    const isRemote = process.env.DATABASE_URL.includes("supabase") || process.env.DATABASE_URL.includes("neon") || process.env.DATABASE_URL.includes(".com") || process.env.DATABASE_URL.includes(".tech");
    return new Pool({
      connectionString: process.env.DATABASE_URL,
      max: 10,
      idleTimeoutMillis: 1e4,
      connectionTimeoutMillis: 1e4,
      keepAlive: true,
      keepAliveInitialDelayMillis: 1e4,
      ssl: isRemote ? { rejectUnauthorized: false } : void 0
    });
  }
  return new Pool();
};
var pool = createPool();
pool.on("error", (err) => {
  console.error("Unexpected error on idle SQL pool client:", err);
});
var db = (0, import_node_postgres.drizzle)(pool, { schema: schema_exports });
var runMigrations = async () => {
  try {
    const migrationsFolder = import_path.default.join(process.cwd(), "drizzle");
    console.log(`[Database] Checking for migrations in ${migrationsFolder}...`);
    await (0, import_migrator.migrate)(db, { migrationsFolder });
    console.log("[Database] Migrations applied successfully!");
  } catch (error) {
    console.error("[Database] Migration failed:", error);
  }
};

// server.ts
var import_drizzle_orm = require("drizzle-orm");
var import_nodemailer = __toESM(require("nodemailer"), 1);
var import_jsonwebtoken = __toESM(require("jsonwebtoken"), 1);
var import_http = __toESM(require("http"), 1);
var import_socket = require("socket.io");
var import_web_push = __toESM(require("web-push"), 1);
var import_helmet = __toESM(require("helmet"), 1);
var import_cors = __toESM(require("cors"), 1);
var import_express_rate_limit = __toESM(require("express-rate-limit"), 1);
var vapidPublicKey = process.env.VAPID_PUBLIC_KEY || "BPEg3-o75k9oT_P58tN3X8w3D0aC7CgT8Qd2lE_244FqL9c-859ZpA34A_R-V9t-V7h48x3Yp8M06xR61O4hXwI";
var vapidPrivateKey = process.env.VAPID_PRIVATE_KEY || "J8YgXo1Qz64H9Q8x-6yR-3rF2t5Y8_4wD3zF0_6z5K8";
import_web_push.default.setVapidDetails(
  "mailto:support@owodefood.com",
  vapidPublicKey,
  vapidPrivateKey
);
var JWT_SECRET = process.env.JWT_SECRET || "secure_fallback_secret_xyz123";
var verifyTokenOptional = (req, res, next) => {
  const authHeader = req.headers.authorization;
  const xAuthHeader = req.headers["x-auth-token"];
  let token = "";
  if (authHeader && authHeader.startsWith("Bearer ")) {
    token = authHeader.split(" ")[1];
  } else if (xAuthHeader) {
    token = xAuthHeader;
  }
  if (token) {
    try {
      req.user = import_jsonwebtoken.default.verify(token, JWT_SECRET);
    } catch (e) {
      req.jwtError = e.message;
    }
  }
  next();
};
var app = (0, import_express.default)();
var PORT = process.env.PORT || 3e3;
var server = import_http.default.createServer(app);
var io = new import_socket.Server(server, {
  cors: {
    origin: process.env.NODE_ENV === "production" ? false : "http://localhost:5173",
    methods: ["GET", "POST"]
  }
});
io.on("connection", (socket) => {
  socket.on("join", (userId) => {
    socket.join(userId);
  });
});
app.use((0, import_helmet.default)({
  contentSecurityPolicy: false
  // Disable CSP if it interferes with Vite dev server or external images
}));
app.use((0, import_cors.default)({
  origin: process.env.NODE_ENV === "production" ? false : "http://localhost:5173"
}));
app.set("trust proxy", 1);
var authLimiter = (0, import_express_rate_limit.default)({
  windowMs: 15 * 60 * 1e3,
  max: 100,
  message: { error: "Too many requests from this IP, please try again after 15 minutes." },
  standardHeaders: true,
  legacyHeaders: false
});
app.use(import_express.default.json({ limit: "50mb" }));
var transporter = null;
function getMailTransporter() {
  if (!transporter) {
    const host = process.env.SMTP_HOST || "smtp.zeptomail.com";
    const port = Number(process.env.SMTP_PORT) || 587;
    const secure = process.env.SMTP_SECURE === "true" || port === 465;
    const user = process.env.SMTP_USER || "emailapikey";
    const pass = process.env.SMTP_PASS;
    if (!pass) {
      console.warn("SMTP_PASS is not configured. Email notifications will operate in STDOUT simulation mode.");
      return null;
    }
    transporter = import_nodemailer.default.createTransport({
      host,
      port,
      secure,
      auth: {
        user,
        pass
      }
    });
  }
  return transporter;
}
async function sendEmailNotification(to, subject, htmlContent) {
  try {
    const mailer = getMailTransporter();
    const fromName = process.env.SMTP_FROM_NAME || "Owode Food";
    const fromEmail = process.env.SMTP_FROM_EMAIL || "noreply@owodefood.com";
    if (!mailer) {
      console.log(`[SMTP SIMULATION] TO: ${to}
SUBJECT: ${subject}
HTML:
${htmlContent}
====================`);
      return { success: true, simulated: true };
    }
    const info = await mailer.sendMail({
      from: `"${fromName}" <${fromEmail}>`,
      to,
      subject,
      html: htmlContent
    });
    console.log(`[SMTP SUCCESS] Message sent successfully to ${to}. ID: ${info.messageId}`);
    return { success: true, messageId: info.messageId };
  } catch (err) {
    console.error("[SMTP ERROR] Failed to deliver secure email:", err.message || err);
    return { success: false, error: err.message || String(err) };
  }
}
app.get("/api/health", (req, res) => {
  res.json({ status: "ok", database: "connected" });
});
app.post("/api/email/test", async (req, res) => {
  const { toEmail } = req.body;
  if (!toEmail) {
    return res.status(400).json({ error: "Missing recipient email address ('toEmail')" });
  }
  const result = await sendEmailNotification(
    toEmail,
    "Owode Food - Live SMTP Connection Verification",
    `
    <div style="font-family: 'Helvetica Neue', Helvetica, Arial, sans-serif; max-width: 600px; margin: 40px auto; padding: 30px; border: 1px solid #e5e7eb; border-radius: 16px; background-color: #ffffff; box-shadow: 0 4px 12px rgba(0,0,0,0.03);">
      <div style="text-align: center; margin-bottom: 24px;">
        <span style="font-size: 32px;">\u{1F354}</span>
        <h2 style="color: #070329; margin: 10px 0 0 0; font-size: 22px; font-weight: 800; letter-spacing: -0.5px; text-transform: uppercase;">Owode Food Marketplace</h2>
        <span style="font-size: 10px; color: #3b82f6; font-weight: bold; letter-spacing: 1px; text-transform: uppercase;">SMTP Secure Relay Connected</span>
      </div>
      <p style="font-size: 14px; color: #374151; line-height: 1.6;">Hello,</p>
      <p style="font-size: 14px; color: #374151; line-height: 1.6;">This is a test notification confirming that your <strong>ZeptoMail SMTP server connection</strong> has been successfully integrated and is fully operational on your <strong>Owode Food Multi-Vendor Platform</strong>.</p>
      
      <div style="background-color: #f8fafc; border: 1px solid #f1f5f9; padding: 16px; border-radius: 12px; margin: 24px 0;">
        <span style="font-size: 11px; text-transform: uppercase; font-weight: bold; color: #64748b; display: block; margin-bottom: 8px;">Technical Handshake Metadata</span>
        <table style="width: 100%; border-collapse: collapse; font-size: 12px; color: #334155;">
          <tr>
            <td style="padding: 4px 0; font-weight: bold; width: 120px;">SMTP Gateway:</td>
            <td style="padding: 4px 0; font-family: monospace;">${process.env.SMTP_HOST || "smtp.zeptomail.com"}</td>
          </tr>
          <tr>
            <td style="padding: 4px 0; font-weight: bold;">Handshake Port:</td>
            <td style="padding: 4px 0; font-family: monospace;">${process.env.SMTP_PORT || "587"}</td>
          </tr>
          <tr>
            <td style="padding: 4px 0; font-weight: bold;">Verified Recipient:</td>
            <td style="padding: 4px 0; font-family: monospace; color: #0f172a;">${toEmail}</td>
          </tr>
        </table>
      </div>

      <p style="font-size: 14px; color: #374151; line-height: 1.6;">Real-time automated emails will now trigger securely for registration approvals, instant wallets funding receipting, and multi-vendor dispatch trackings.</p>
      
      <hr style="border: none; border-top: 1px solid #f1f5f9; margin: 24px 0;" />
      <div style="text-align: center;">
        <p style="font-size: 11px; color: #94a3b8; margin: 0;">Sent via Owode Food Core Infrastructure Services</p>
        <p style="font-size: 10px; color: #cbd5e1; margin: 4px 0 0 0;">Do not reply to this automated transaction payload.</p>
      </div>
    </div>
    `
  );
  res.json(result);
});
app.post("/api/email/send-pin", authLimiter, async (req, res) => {
  const { toEmail, name, pin } = req.body;
  if (!toEmail || !pin) {
    return res.status(400).json({ error: "Missing recipient email address ('toEmail') or PIN code ('pin')" });
  }
  const result = await sendEmailNotification(
    toEmail,
    `Owode Food - ${pin} is your secure login verification PIN`,
    `
    <div style="font-family: 'Helvetica Neue', Helvetica, Arial, sans-serif; max-width: 600px; margin: 40px auto; padding: 30px; border: 1px solid #e5e7eb; border-radius: 16px; background-color: #ffffff; box-shadow: 0 4px 12px rgba(0,0,0,0.03);">
      <div style="text-align: center; margin-bottom: 24px;">
        <span style="font-size: 32px;">\u{1F354}</span>
        <h2 style="color: #070329; margin: 10px 0 0 0; font-size: 22px; font-weight: 800; letter-spacing: -0.5px; text-transform: uppercase;">Owode Food</h2>
        <span style="font-size: 10px; color: #3b82f6; font-weight: bold; letter-spacing: 1px; text-transform: uppercase;">Secure Account Verification</span>
      </div>
      <p style="font-size: 14px; color: #374151; line-height: 1.6;">Hello ${name || "User"},</p>
      <p style="font-size: 14px; color: #374151; line-height: 1.6;">To complete your sign in on <strong>Owode Food</strong>, please use the following secure 4-digit verification PIN:</p>
      
      <div style="text-align: center; margin: 30px 0;">
        <span style="display: inline-block; background-color: #f1f5f9; color: #070329; font-size: 32px; font-weight: 800; padding: 12px 30px; border-radius: 12px; letter-spacing: 8px; font-family: monospace; border: 1px solid #e2e8f0;">${pin}</span>
      </div>

      <p style="font-size: 12px; color: #64748b; line-height: 1.6; text-align: center;">This PIN is valid for 10 minutes. Please do not share this code with anyone.</p>
      
      <hr style="border: none; border-top: 1px solid #f1f5f9; margin: 24px 0;" />
      <div style="text-align: center;">
        <p style="font-size: 11px; color: #94a3b8; margin: 0;">Sent via Owode Food Secure Services</p>
        <p style="font-size: 10px; color: #cbd5e1; margin: 4px 0 0 0;">If you did not request this, please ignore this email.</p>
      </div>
    </div>
    `
  );
  if (!result.success) {
    console.error(`[SECURE LOG] Email delivery failed for ${toEmail}. The generated PIN was: ${pin}`);
  } else {
    console.log(`[SECURE LOG] PIN successfully sent to ${toEmail}`);
  }
  res.json(result);
});
app.post("/api/login", authLimiter, async (req, res) => {
  try {
    let { email, pin } = req.body;
    if (!email || !pin) return res.status(400).json({ error: "Missing email or PIN" });
    email = email.trim().toLowerCase();
    const existingUsers = await db.select().from(users).where((0, import_drizzle_orm.eq)(users.email, email));
    const user = existingUsers[0];
    if (!user || user.pin !== pin) {
      return res.status(401).json({ error: "Invalid credentials" });
    }
    const token = import_jsonwebtoken.default.sign(
      { id: user.id, role: user.role, roles: user.roles, email: user.email },
      JWT_SECRET,
      { expiresIn: "7d" }
    );
    res.json({ success: true, token, user });
  } catch (error) {
    console.error("Login error:", error);
    res.status(500).json({ error: "Login process failed: " + (error.message || String(error)) });
  }
});
app.get("/api/sync/load", async (req, res) => {
  try {
    const allUsers = await db.select().from(users);
    const allVendors = await db.select().from(vendors);
    const allProducts = await db.select().from(products);
    const allOrders = await db.select().from(orders);
    const allOrderItems = await db.select().from(orderItems);
    const allRiders = await db.select().from(riders);
    const allPaymentGateways = await db.select().from(paymentGateways);
    const allSavedAddresses = await db.select().from(userSavedAddresses);
    const allExtremeLocationTiers = await db.select().from(extremeLocationTiers);
    const allExtremeLocations = await db.select().from(extremeLocations);
    const allEmployees = await db.select().from(employees);
    const allSystemSettings = await db.select().from(systemSettings);
    const allReviews = await db.select().from(reviews);
    const allWalletTransactions = await db.select().from(walletTransactions);
    const allAppNotifications = await db.select().from(appNotifications);
    const allReceiptPickupOrders = await db.select().from(receiptPickupOrders);
    res.json({
      users: allUsers,
      vendors: allVendors,
      products: allProducts,
      orders: allOrders.map((o) => {
        const items = allOrderItems.filter((oi) => oi.orderId === o.id);
        return { ...o, items };
      }),
      riders: allRiders,
      paymentGateways: allPaymentGateways,
      savedAddresses: allSavedAddresses,
      extremeLocationTiers: allExtremeLocationTiers,
      extremeLocations: allExtremeLocations,
      employees: allEmployees,
      reviews: allReviews,
      walletTransactions: allWalletTransactions,
      notifications: allAppNotifications,
      receiptPickupOrders: allReceiptPickupOrders,
      systemSettings: allSystemSettings.reduce((acc, setting) => {
        acc[setting.key] = setting.value;
        return acc;
      }, {})
    });
  } catch (error) {
    console.error("Failed to load sync data from Cloud SQL:", error);
    res.status(500).json({ error: "Failed to load database. Please try again later." });
  }
});
app.post("/api/sync/save", verifyTokenOptional, async (req, res) => {
  try {
    const { type, payload } = req.body;
    const reqUser = req.user;
    const isAdmin = reqUser && (reqUser.roles?.includes("admin") || reqUser.roles?.includes("super_admin"));
    const adminOnlyActions = [
      "PRODUCT_DELETE",
      "VENDOR_UPSERT",
      "SYSTEM_SETTING_UPSERT",
      "USERS_BULK",
      "VENDORS_BULK",
      "PRODUCTS_BULK",
      "RIDERS_BULK",
      "ORDERS_BULK",
      "PAYMENT_GATEWAYS_BULK",
      "EXTREME_LOCATION_TIERS_BULK",
      "EXTREME_LOCATIONS_BULK",
      "EMPLOYEES_BULK",
      "REVIEWS_BULK",
      "SYSTEM_SETTINGS_BULK"
    ];
    let isTargetEmpty = false;
    if (adminOnlyActions.includes(type)) {
      if (type === "USERS_BULK") {
        const c = await db.select({ count: import_drizzle_orm.sql`count(*)` }).from(users);
        isTargetEmpty = Number(c[0].count) === 0;
      } else if (type === "VENDORS_BULK") {
        const c = await db.select({ count: import_drizzle_orm.sql`count(*)` }).from(vendors);
        isTargetEmpty = Number(c[0].count) === 0;
      } else if (type === "PRODUCTS_BULK") {
        const c = await db.select({ count: import_drizzle_orm.sql`count(*)` }).from(products);
        isTargetEmpty = Number(c[0].count) === 0;
      } else if (type === "RIDERS_BULK") {
        const c = await db.select({ count: import_drizzle_orm.sql`count(*)` }).from(riders);
        isTargetEmpty = Number(c[0].count) === 0;
      } else if (type === "ORDERS_BULK") {
        const c = await db.select({ count: import_drizzle_orm.sql`count(*)` }).from(orders);
        isTargetEmpty = Number(c[0].count) === 0;
      } else if (type === "PAYMENT_GATEWAYS_BULK") {
        const c = await db.select({ count: import_drizzle_orm.sql`count(*)` }).from(paymentGateways);
        isTargetEmpty = Number(c[0].count) === 0;
      } else if (type === "EXTREME_LOCATION_TIERS_BULK") {
        const c = await db.select({ count: import_drizzle_orm.sql`count(*)` }).from(extremeLocationTiers);
        isTargetEmpty = Number(c[0].count) === 0;
      } else if (type === "EXTREME_LOCATIONS_BULK") {
        const c = await db.select({ count: import_drizzle_orm.sql`count(*)` }).from(extremeLocations);
        isTargetEmpty = Number(c[0].count) === 0;
      } else if (type === "EMPLOYEES_BULK") {
        const c = await db.select({ count: import_drizzle_orm.sql`count(*)` }).from(employees);
        isTargetEmpty = Number(c[0].count) === 0;
      } else if (type === "REVIEWS_BULK") {
        const c = await db.select({ count: import_drizzle_orm.sql`count(*)` }).from(reviews);
        isTargetEmpty = Number(c[0].count) === 0;
      }
    }
    if (!reqUser && type !== "USER_UPSERT" && !isTargetEmpty) {
      return res.status(401).json({ error: "Unauthorized: Please log in." });
    }
    if (adminOnlyActions.includes(type) && !isAdmin && !isTargetEmpty) {
      return res.status(403).json({ error: "Forbidden: Admin access required" });
    }
    if (!type || !payload) {
      return res.status(400).json({ error: "Missing type or payload" });
    }
    switch (type) {
      case "USERS_BULK":
        for (const u of payload) {
          await db.insert(users).values({
            id: u.id,
            email: u.email,
            name: u.name,
            phone: u.phone,
            role: u.role,
            gender: u.gender || null,
            createdAt: u.createdAt,
            pin: u.pin || null,
            roles: u.roles || null
          }).onConflictDoUpdate({
            target: users.id,
            set: {
              email: u.email,
              name: u.name,
              phone: u.phone,
              gender: u.gender || null,
              pin: u.pin || null
            }
          });
        }
        break;
      case "USER_UPSERT": {
        const existing = await db.select().from(users).where((0, import_drizzle_orm.eq)(users.id, payload.id)).limit(1);
        const isNew = existing.length === 0;
        if (!isNew && reqUser && reqUser.id !== payload.id && !isAdmin) {
          return res.status(403).json({ error: "Forbidden: Cannot update other users" });
        }
        const finalRole = isAdmin ? payload.role || "customer" : "customer";
        const finalRoles = isAdmin ? payload.roles || ["customer"] : ["customer"];
        const setBlock = {
          email: payload.email,
          name: payload.name,
          phone: payload.phone,
          gender: payload.gender || null,
          pin: payload.pin || null
        };
        if (isAdmin) {
          setBlock.role = finalRole;
          setBlock.roles = finalRoles;
        }
        await db.insert(users).values({
          id: payload.id,
          email: payload.email,
          name: payload.name,
          phone: payload.phone,
          role: finalRole,
          gender: payload.gender || null,
          createdAt: payload.createdAt || (/* @__PURE__ */ new Date()).toISOString(),
          pin: payload.pin || null,
          roles: finalRoles
        }).onConflictDoUpdate({
          target: users.id,
          set: setBlock
        });
        if (isNew && payload.email) {
          sendEmailNotification(
            payload.email,
            `Welcome to Owode Food, ${payload.name}! \u{1F31F}`,
            `
            <div style="font-family: 'Helvetica Neue', Helvetica, Arial, sans-serif; max-width: 600px; margin: 40px auto; padding: 30px; border: 1px solid #e5e7eb; border-radius: 16px; background-color: #ffffff; box-shadow: 0 4px 12px rgba(0,0,0,0.03);">
              <div style="text-align: center; margin-bottom: 24px;">
                <span style="font-size: 32px;">\u{1F31F}</span>
                <h2 style="color: #070329; margin: 10px 0 0 0; font-size: 22px; font-weight: 800; letter-spacing: -0.5px;">Welcome to Owode Food!</h2>
                <span style="font-size: 10px; color: #10b981; font-weight: bold; letter-spacing: 1px; text-transform: uppercase;">Account Successfully Registered</span>
              </div>
              <p style="font-size: 14px; color: #374151; line-height: 1.6;">Hello <strong>${payload.name}</strong>,</p>
              <p style="font-size: 14px; color: #374151; line-height: 1.6;">Thank you for registering on the <strong>Owode Food Multi-Vendor Marketplace Platform</strong> as a <strong>${payload.role}</strong>. Your account has been provisioned and is ready for use!</p>
              
              <div style="background-color: #f8fafc; border: 1px solid #f1f5f9; padding: 16px; border-radius: 12px; margin: 24px 0;">
                <span style="font-size: 11px; text-transform: uppercase; font-weight: bold; color: #64748b; display: block; margin-bottom: 8px;">Profile Credentials</span>
                <table style="width: 100%; border-collapse: collapse; font-size: 12px; color: #334155;">
                  <tr>
                    <td style="padding: 4px 0; font-weight: bold; width: 120px;">Email Profile:</td>
                    <td style="padding: 4px 0; font-family: monospace;">${payload.email}</td>
                  </tr>
                  <tr>
                    <td style="padding: 4px 0; font-weight: bold;">User Role:</td>
                    <td style="padding: 4px 0; text-transform: uppercase; font-weight: bold; color: #3b82f6;">${payload.role}</td>
                  </tr>
                  <tr>
                    <td style="padding: 4px 0; font-weight: bold;">Registered Phone:</td>
                    <td style="padding: 4px 0; font-family: monospace;">${payload.phone || "Not provided"}</td>
                  </tr>
                </table>
              </div>

              <p style="font-size: 14px; color: #374151; line-height: 1.6;">You can now fund your secure sandbox <strong>Owode Food Wallet</strong>, configure delivery addresses, browse local food vendors, and track your orders in real-time.</p>
              
              <hr style="border: none; border-top: 1px solid #f1f5f9; margin: 24px 0;" />
              <div style="text-align: center;">
                <p style="font-size: 11px; color: #94a3b8; margin: 0;">Sent via Owode Food Core Platform Services</p>
              </div>
            </div>
            `
          ).catch((err) => console.error("Error sending registration welcome email:", err));
        }
        break;
      }
      case "VENDORS_BULK":
        for (const v of payload) {
          await db.insert(vendors).values({
            id: v.id,
            userId: v.userId,
            name: v.name,
            description: v.description,
            cuisine: v.cuisine,
            image: v.image,
            rating: Number(v.rating) || 5,
            address: v.address,
            status: v.status,
            createdAt: v.createdAt,
            openingTime: v.openingTime,
            closingTime: v.closingTime,
            openingDays: v.openingDays,
            coverImage: v.coverImage,
            category: v.category,
            prepTime: v.prepTime,
            deliveryFee: v.deliveryFee,
            serviceFee: v.serviceFee,
            serviceFeeType: v.serviceFeeType,
            serviceFeeValue: v.serviceFeeValue,
            commissionType: v.commissionType,
            commissionValue: v.commissionValue,
            freeDelivery: v.freeDelivery
          }).onConflictDoUpdate({
            target: vendors.id,
            set: {
              userId: v.userId,
              name: v.name,
              description: v.description,
              cuisine: v.cuisine,
              image: v.image,
              rating: Number(v.rating) || 5,
              address: v.address,
              status: v.status,
              openingTime: v.openingTime,
              closingTime: v.closingTime,
              openingDays: v.openingDays,
              coverImage: v.coverImage,
              category: v.category,
              prepTime: v.prepTime,
              deliveryFee: v.deliveryFee,
              serviceFee: v.serviceFee,
              serviceFeeType: v.serviceFeeType,
              serviceFeeValue: v.serviceFeeValue,
              commissionType: v.commissionType,
              commissionValue: v.commissionValue,
              freeDelivery: v.freeDelivery
            }
          });
        }
        break;
      case "VENDOR_UPSERT":
        await db.insert(vendors).values({
          id: payload.id,
          userId: payload.userId,
          name: payload.name,
          description: payload.description,
          cuisine: payload.cuisine,
          image: payload.image,
          rating: Number(payload.rating) || 5,
          address: payload.address,
          status: payload.status,
          createdAt: payload.createdAt || (/* @__PURE__ */ new Date()).toISOString(),
          openingTime: payload.openingTime,
          closingTime: payload.closingTime,
          openingDays: payload.openingDays,
          coverImage: payload.coverImage,
          category: payload.category,
          prepTime: payload.prepTime,
          deliveryFee: payload.deliveryFee,
          serviceFee: payload.serviceFee,
          serviceFeeType: payload.serviceFeeType,
          serviceFeeValue: payload.serviceFeeValue,
          commissionType: payload.commissionType,
          commissionValue: payload.commissionValue,
          freeDelivery: payload.freeDelivery
        }).onConflictDoUpdate({
          target: vendors.id,
          set: {
            userId: payload.userId,
            name: payload.name,
            description: payload.description,
            cuisine: payload.cuisine,
            image: payload.image,
            rating: Number(payload.rating) || 5,
            address: payload.address,
            status: payload.status,
            openingTime: payload.openingTime,
            closingTime: payload.closingTime,
            openingDays: payload.openingDays,
            coverImage: payload.coverImage,
            category: payload.category,
            prepTime: payload.prepTime,
            deliveryFee: payload.deliveryFee,
            serviceFee: payload.serviceFee,
            serviceFeeType: payload.serviceFeeType,
            serviceFeeValue: payload.serviceFeeValue,
            commissionType: payload.commissionType,
            commissionValue: payload.commissionValue,
            freeDelivery: payload.freeDelivery
          }
        });
        break;
      case "PRODUCTS_BULK":
        for (const p of payload) {
          await db.insert(products).values({
            id: p.id,
            vendorId: p.vendorId,
            name: p.name,
            description: p.description,
            price: Math.round(p.price),
            image: p.image,
            category: p.category,
            isAvailable: p.isAvailable,
            createdAt: p.createdAt,
            addons: p.addons,
            maxAddons: p.maxAddons,
            addonGroups: p.addonGroups || null
          }).onConflictDoUpdate({
            target: products.id,
            set: {
              vendorId: p.vendorId,
              name: p.name,
              description: p.description,
              price: Math.round(p.price),
              image: p.image,
              category: p.category,
              isAvailable: p.isAvailable,
              addons: p.addons,
              maxAddons: p.maxAddons,
              addonGroups: p.addonGroups || null
            }
          });
        }
        break;
      case "PRODUCT_UPSERT":
        await db.insert(products).values({
          id: payload.id,
          vendorId: payload.vendorId,
          name: payload.name,
          description: payload.description,
          price: Math.round(payload.price),
          image: payload.image,
          category: payload.category,
          isAvailable: payload.isAvailable,
          createdAt: payload.createdAt || (/* @__PURE__ */ new Date()).toISOString(),
          addons: payload.addons,
          maxAddons: payload.maxAddons,
          addonGroups: payload.addonGroups || null
        }).onConflictDoUpdate({
          target: products.id,
          set: {
            vendorId: payload.vendorId,
            name: payload.name,
            description: payload.description,
            price: Math.round(payload.price),
            image: payload.image,
            category: payload.category,
            isAvailable: payload.isAvailable,
            addons: payload.addons,
            maxAddons: payload.maxAddons,
            addonGroups: payload.addonGroups || null
          }
        });
        break;
      case "PRODUCT_DELETE":
        await db.delete(products).where((0, import_drizzle_orm.eq)(products.id, payload.id));
        break;
      case "ORDERS_BULK":
        for (const o of payload) {
          await db.insert(orders).values({
            id: o.id,
            customerId: o.customerId,
            customerName: o.customerName,
            customerPhone: o.customerPhone,
            vendorId: o.vendorId,
            vendorName: o.vendorName,
            riderId: o.riderId,
            riderName: o.riderName,
            status: o.status,
            totalAmount: Math.round(o.totalAmount),
            deliveryAddress: o.deliveryAddress,
            paymentMethod: o.paymentMethod,
            createdAt: o.createdAt,
            serviceFee: o.serviceFee,
            deliveryFee: o.deliveryFee,
            tax: o.tax
          }).onConflictDoUpdate({
            target: orders.id,
            set: {
              status: o.status,
              riderId: o.riderId,
              riderName: o.riderName
            }
          });
          if (o.items && Array.isArray(o.items)) {
            for (const item of o.items) {
              await db.insert(orderItems).values({
                id: item.id || `${o.id}-${item.productId}`,
                orderId: o.id,
                productId: item.productId,
                name: item.name,
                price: Math.round(item.price),
                quantity: item.quantity
              }).onConflictDoUpdate({
                target: orderItems.id,
                set: {
                  quantity: item.quantity
                }
              });
            }
          }
        }
        break;
      case "ORDER_UPSERT": {
        const existingOrder = await db.select().from(orders).where((0, import_drizzle_orm.eq)(orders.id, payload.id)).limit(1);
        const isNew = existingOrder.length === 0;
        const oldStatus = isNew ? null : existingOrder[0].status;
        const statusChanged = oldStatus !== payload.status;
        await db.insert(orders).values({
          id: payload.id,
          customerId: payload.customerId,
          customerName: payload.customerName,
          customerPhone: payload.customerPhone,
          vendorId: payload.vendorId,
          vendorName: payload.vendorName,
          riderId: payload.riderId,
          riderName: payload.riderName,
          status: payload.status,
          totalAmount: Math.round(payload.totalAmount),
          deliveryAddress: payload.deliveryAddress,
          paymentMethod: payload.paymentMethod,
          createdAt: payload.createdAt || (/* @__PURE__ */ new Date()).toISOString(),
          serviceFee: payload.serviceFee,
          deliveryFee: payload.deliveryFee,
          tax: payload.tax
        }).onConflictDoUpdate({
          target: orders.id,
          set: {
            status: payload.status,
            riderId: payload.riderId,
            riderName: payload.riderName
          }
        });
        if (payload.items && Array.isArray(payload.items)) {
          for (const item of payload.items) {
            await db.insert(orderItems).values({
              id: item.id || `${payload.id}-${item.productId}`,
              orderId: payload.id,
              productId: item.productId,
              name: item.name,
              price: Math.round(item.price),
              quantity: item.quantity
            }).onConflictDoUpdate({
              target: orderItems.id,
              set: {
                quantity: item.quantity
              }
            });
          }
        }
        if (payload.customerId) {
          const customerRecords = await db.select().from(users).where((0, import_drizzle_orm.eq)(users.id, payload.customerId)).limit(1);
          if (customerRecords.length > 0 && customerRecords[0].email) {
            const customerEmail = customerRecords[0].email;
            if (isNew) {
              sendEmailNotification(
                customerEmail,
                `Order Placed Successfully! #${payload.id.substring(0, 8)} \u{1F6CD}\uFE0F`,
                `
                <div style="font-family: 'Helvetica Neue', Helvetica, Arial, sans-serif; max-width: 600px; margin: 40px auto; padding: 30px; border: 1px solid #e5e7eb; border-radius: 16px; background-color: #ffffff; box-shadow: 0 4px 12px rgba(0,0,0,0.03);">
                  <div style="text-align: center; margin-bottom: 24px;">
                    <span style="font-size: 32px;">\u{1F6CD}\uFE0F</span>
                    <h2 style="color: #070329; margin: 10px 0 0 0; font-size: 22px; font-weight: 800; letter-spacing: -0.5px;">Order Placed Successfully!</h2>
                    <span style="font-size: 10px; color: #3b82f6; font-weight: bold; letter-spacing: 1px; text-transform: uppercase;">Awaiting Vendor Acceptance</span>
                  </div>
                  <p style="font-size: 14px; color: #374151; line-height: 1.6;">Hello <strong>${payload.customerName || "Customer"}</strong>,</p>
                  <p style="font-size: 14px; color: #374151; line-height: 1.6;">Your order at <strong>${payload.vendorName}</strong> has been received and is currently being prepared for the kitchen.</p>
                  
                  <div style="background-color: #f8fafc; border: 1px solid #f1f5f9; padding: 16px; border-radius: 12px; margin: 24px 0;">
                    <span style="font-size: 11px; text-transform: uppercase; font-weight: bold; color: #64748b; display: block; margin-bottom: 8px;">Order Details</span>
                    <table style="width: 100%; border-collapse: collapse; font-size: 12px; color: #334155;">
                      <tr>
                        <td style="padding: 4px 0; font-weight: bold; width: 120px;">Order ID:</td>
                        <td style="padding: 4px 0; font-family: monospace; color: #0f172a;">#${payload.id}</td>
                      </tr>
                      <tr>
                        <td style="padding: 4px 0; font-weight: bold;">Vendor:</td>
                        <td style="padding: 4px 0; font-weight: bold; color: #070329;">${payload.vendorName}</td>
                      </tr>
                      <tr>
                        <td style="padding: 4px 0; font-weight: bold;">Total Amount:</td>
                        <td style="padding: 4px 0; font-weight: bold; color: #10b981;">\u20A6${payload.totalAmount.toLocaleString()}</td>
                      </tr>
                      <tr>
                        <td style="padding: 4px 0; font-weight: bold;">Delivery To:</td>
                        <td style="padding: 4px 0;">${payload.deliveryAddress}</td>
                      </tr>
                      <tr>
                        <td style="padding: 4px 0; font-weight: bold;">Payment Mode:</td>
                        <td style="padding: 4px 0; font-family: monospace;">${payload.paymentMethod}</td>
                      </tr>
                    </table>
                  </div>

                  <p style="font-size: 14px; color: #374151; line-height: 1.6;">You can track the live preparation status and courier delivery tracking of your order directly from your Owode Food customer panel.</p>
                  
                  <hr style="border: none; border-top: 1px solid #f1f5f9; margin: 24px 0;" />
                  <div style="text-align: center;">
                    <p style="font-size: 11px; color: #94a3b8; margin: 0;">Sent via Owode Food Core Platform Services</p>
                  </div>
                </div>
                `
              ).catch((err) => console.error("Error sending order placement email:", err));
            } else if (statusChanged) {
              sendEmailNotification(
                customerEmail,
                `Order #${payload.id.substring(0, 8)} Status Update: ${payload.status.toUpperCase()} \u26A1`,
                `
                <div style="font-family: 'Helvetica Neue', Helvetica, Arial, sans-serif; max-width: 600px; margin: 40px auto; padding: 30px; border: 1px solid #e5e7eb; border-radius: 16px; background-color: #ffffff; box-shadow: 0 4px 12px rgba(0,0,0,0.03);">
                  <div style="text-align: center; margin-bottom: 24px;">
                    <span style="font-size: 32px;">\u26A1</span>
                    <h2 style="color: #070329; margin: 10px 0 0 0; font-size: 22px; font-weight: 800; letter-spacing: -0.5px;">Order Status Update!</h2>
                    <span style="font-size: 10px; color: #0ea5e9; font-weight: bold; letter-spacing: 1px; text-transform: uppercase; background-color: #f0f9ff; padding: 4px 12px; border-radius: 20px;">${payload.status}</span>
                  </div>
                  <p style="font-size: 14px; color: #374151; line-height: 1.6;">Hello <strong>${payload.customerName || "Customer"}</strong>,</p>
                  <p style="font-size: 14px; color: #374151; line-height: 1.6;">The status of your order at <strong>${payload.vendorName}</strong> has been updated.</p>
                  
                  <div style="background-color: #f8fafc; border: 1px solid #f1f5f9; padding: 16px; border-radius: 12px; margin: 24px 0;">
                    <span style="font-size: 11px; text-transform: uppercase; font-weight: bold; color: #64748b; display: block; margin-bottom: 8px;">Update Details</span>
                    <table style="width: 100%; border-collapse: collapse; font-size: 12px; color: #334155;">
                      <tr>
                        <td style="padding: 4px 0; font-weight: bold; width: 120px;">Order ID:</td>
                        <td style="padding: 4px 0; font-family: monospace; color: #0f172a;">#${payload.id}</td>
                      </tr>
                      <tr>
                        <td style="padding: 4px 0; font-weight: bold;">Current Status:</td>
                        <td style="padding: 4px 0; font-weight: bold; color: #0ea5e9; text-transform: uppercase;">${payload.status}</td>
                      </tr>
                      ${payload.riderName ? `
                      <tr>
                        <td style="padding: 4px 0; font-weight: bold;">Courier Rider:</td>
                        <td style="padding: 4px 0; font-weight: bold; color: #3b82f6;">${payload.riderName}</td>
                      </tr>
                      ` : ""}
                    </table>
                  </div>

                  <p style="font-size: 14px; color: #374151; line-height: 1.6;">Your tracking feed will reflect this update immediately. Thank you for choosing Owode Food!</p>
                  
                  <hr style="border: none; border-top: 1px solid #f1f5f9; margin: 24px 0;" />
                  <div style="text-align: center;">
                    <p style="font-size: 11px; color: #94a3b8; margin: 0;">Sent via Owode Food Core Platform Services</p>
                  </div>
                </div>
                `
              ).catch((err) => console.error("Error sending order status change email:", err));
            }
          }
        }
        if (statusChanged && payload.status === "accepted" && !payload.riderId) {
          io.to("riders").emit("new_delivery_job", { orderId: payload.id, vendorName: payload.vendorName });
          try {
            const activeRiders = await db.select().from(riders).where((0, import_drizzle_orm.eq)(riders.isAvailable, true));
            const riderUserIds = activeRiders.map((r) => r.userId);
            if (riderUserIds.length > 0) {
              const subs = await db.select().from(pushSubscriptions).where((0, import_drizzle_orm.inArray)(pushSubscriptions.userId, riderUserIds));
              for (const sub of subs) {
                try {
                  await import_web_push.default.sendNotification({
                    endpoint: sub.endpoint,
                    keys: { p256dh: sub.p256dh, auth: sub.auth }
                  }, JSON.stringify({
                    title: "New Delivery Job! \u{1F6F5}",
                    message: `Order #${payload.id.substring(0, 8)} from ${payload.vendorName} is available.`
                  }));
                } catch (e) {
                  if (e.statusCode === 410 || e.statusCode === 404) {
                    await db.delete(pushSubscriptions).where((0, import_drizzle_orm.eq)(pushSubscriptions.id, sub.id));
                  }
                }
              }
            }
          } catch (e) {
            console.error("Rider push failed", e);
          }
        }
        break;
      }
      case "RIDERS_BULK":
        for (const r of payload) {
          await db.insert(riders).values({
            id: r.id,
            userId: r.userId,
            name: r.name,
            phone: r.phone,
            vehicleType: r.vehicleType,
            status: r.status,
            isAvailable: r.isAvailable,
            createdAt: r.createdAt
          }).onConflictDoUpdate({
            target: riders.id,
            set: {
              name: r.name,
              phone: r.phone,
              vehicleType: r.vehicleType,
              status: r.status,
              isAvailable: r.isAvailable
            }
          });
        }
        break;
      case "RIDER_UPSERT":
        await db.insert(riders).values({
          id: payload.id,
          userId: payload.userId,
          name: payload.name,
          phone: payload.phone,
          vehicleType: payload.vehicleType,
          status: payload.status,
          isAvailable: payload.isAvailable,
          createdAt: payload.createdAt || (/* @__PURE__ */ new Date()).toISOString()
        }).onConflictDoUpdate({
          target: riders.id,
          set: {
            name: payload.name,
            phone: payload.phone,
            vehicleType: payload.vehicleType,
            status: payload.status,
            isAvailable: payload.isAvailable
          }
        });
        break;
      case "PAYMENT_GATEWAYS_BULK":
        for (const pg2 of payload) {
          await db.insert(paymentGateways).values({
            id: pg2.id,
            name: pg2.name,
            desc: pg2.desc,
            isEnabled: pg2.isEnabled,
            apiKey: pg2.apiKey,
            secretKey: pg2.secretKey,
            contractCode: pg2.contractCode,
            bankName: pg2.bankName,
            accountNumber: pg2.accountNumber,
            accountName: pg2.accountName,
            isActive: pg2.isActive
          }).onConflictDoUpdate({
            target: paymentGateways.id,
            set: {
              name: pg2.name,
              desc: pg2.desc,
              isEnabled: pg2.isEnabled,
              apiKey: pg2.apiKey,
              secretKey: pg2.secretKey,
              contractCode: pg2.contractCode,
              bankName: pg2.bankName,
              accountNumber: pg2.accountNumber,
              accountName: pg2.accountName,
              isActive: pg2.isActive
            }
          });
        }
        break;
      case "USER_SAVED_ADDRESSES_BULK":
        for (const sa of payload) {
          await db.insert(userSavedAddresses).values({
            id: sa.id,
            userId: sa.userId,
            streetAddress: sa.streetAddress,
            district: sa.district,
            landmarkNote: sa.landmarkNote
          }).onConflictDoUpdate({
            target: userSavedAddresses.id,
            set: {
              streetAddress: sa.streetAddress,
              district: sa.district,
              landmarkNote: sa.landmarkNote
            }
          });
        }
        break;
      case "USER_SAVED_ADDRESS_UPSERT":
        await db.insert(userSavedAddresses).values({
          id: payload.id,
          userId: payload.userId,
          streetAddress: payload.streetAddress,
          district: payload.district,
          landmarkNote: payload.landmarkNote
        }).onConflictDoUpdate({
          target: userSavedAddresses.id,
          set: {
            streetAddress: payload.streetAddress,
            district: payload.district,
            landmarkNote: payload.landmarkNote
          }
        });
        break;
      case "USER_SAVED_ADDRESS_DELETE":
        await db.delete(userSavedAddresses).where((0, import_drizzle_orm.eq)(userSavedAddresses.id, payload.id));
        break;
      case "EXTREME_LOCATION_TIERS_BULK":
        for (const elt of payload) {
          await db.insert(extremeLocationTiers).values({
            id: elt.id,
            name: elt.name,
            surcharge: Math.round(elt.surcharge)
          }).onConflictDoUpdate({
            target: extremeLocationTiers.id,
            set: {
              name: elt.name,
              surcharge: Math.round(elt.surcharge)
            }
          });
        }
        break;
      case "EXTREME_LOCATIONS_BULK":
        await db.delete(extremeLocations);
        for (const el of payload) {
          await db.insert(extremeLocations).values({
            id: el.id,
            name: el.name,
            tierId: el.tierId
          });
        }
        break;
      case "EXTREME_LOCATION_UPSERT":
        await db.insert(extremeLocations).values({
          id: payload.id,
          name: payload.name,
          tierId: payload.tierId
        }).onConflictDoUpdate({
          target: extremeLocations.id,
          set: {
            name: payload.name,
            tierId: payload.tierId
          }
        });
        break;
      case "EXTREME_LOCATION_DELETE":
        await db.delete(extremeLocations).where((0, import_drizzle_orm.eq)(extremeLocations.id, payload.id));
        break;
      case "EMPLOYEES_BULK":
        for (const emp of payload) {
          await db.insert(employees).values({
            id: emp.id,
            name: emp.name,
            email: emp.email,
            phone: emp.phone,
            department: emp.department,
            status: emp.status,
            permissions: emp.permissions,
            createdAt: emp.createdAt
          }).onConflictDoUpdate({
            target: employees.id,
            set: {
              name: emp.name,
              email: emp.email,
              phone: emp.phone,
              department: emp.department,
              status: emp.status,
              permissions: emp.permissions
            }
          });
        }
        break;
      case "SYSTEM_SETTINGS_BULK":
        for (const setting of payload) {
          if (!setting.key || setting.value === void 0 || setting.value === null) continue;
          await db.insert(systemSettings).values({
            key: setting.key,
            value: String(setting.value)
          }).onConflictDoUpdate({
            target: systemSettings.key,
            set: { value: String(setting.value) }
          });
        }
        break;
      case "EMPLOYEE_UPSERT":
        await db.insert(employees).values({
          id: payload.id,
          name: payload.name,
          email: payload.email,
          phone: payload.phone,
          department: payload.department,
          status: payload.status,
          permissions: payload.permissions,
          createdAt: payload.createdAt || (/* @__PURE__ */ new Date()).toISOString()
        }).onConflictDoUpdate({
          target: employees.id,
          set: {
            name: payload.name,
            email: payload.email,
            phone: payload.phone,
            department: payload.department,
            status: payload.status,
            permissions: payload.permissions
          }
        });
        break;
      case "EMPLOYEE_DELETE":
        await db.delete(employees).where((0, import_drizzle_orm.eq)(employees.id, payload.id));
        break;
      case "USER_DELETE":
        await db.delete(users).where((0, import_drizzle_orm.eq)(users.id, payload.id));
        break;
      case "SYSTEM_SETTING_UPSERT":
        await db.insert(systemSettings).values({
          key: payload.key,
          value: String(payload.value)
        }).onConflictDoUpdate({
          target: systemSettings.key,
          set: {
            value: String(payload.value)
          }
        });
        break;
      case "REVIEWS_BULK":
        for (const r of payload) {
          await db.insert(reviews).values({
            id: r.id,
            vendorId: r.vendorId,
            customerId: r.customerId,
            author: r.author,
            rating: Number(r.rating),
            comment: r.comment,
            createdAt: r.createdAt
          }).onConflictDoUpdate({
            target: reviews.id,
            set: {
              vendorId: r.vendorId,
              customerId: r.customerId,
              author: r.author,
              rating: Number(r.rating),
              comment: r.comment,
              createdAt: r.createdAt
            }
          });
        }
        break;
      case "REVIEW_UPSERT":
        await db.insert(reviews).values({
          id: payload.id,
          vendorId: payload.vendorId,
          customerId: payload.customerId,
          author: payload.author,
          rating: Number(payload.rating),
          comment: payload.comment,
          createdAt: payload.createdAt || (/* @__PURE__ */ new Date()).toISOString()
        }).onConflictDoUpdate({
          target: reviews.id,
          set: {
            vendorId: payload.vendorId,
            customerId: payload.customerId,
            author: payload.author,
            rating: Number(payload.rating),
            comment: payload.comment,
            createdAt: payload.createdAt || (/* @__PURE__ */ new Date()).toISOString()
          }
        });
        break;
      default:
        return res.status(400).json({ error: `Unknown synchronization type: ${type}` });
    }
    res.json({ success: true });
  } catch (error) {
    console.error("Cloud SQL sync save failed:", error);
    res.status(500).json({ error: "Failed to sync updates to Cloud SQL database." });
  }
});
app.post("/api/checkout", verifyTokenOptional, async (req, res) => {
  try {
    const { customerId, customerName, customerPhone, vendorId, vendorName, items, deliveryAddress, paymentMethod, serviceFee, deliveryFee, tax } = req.body;
    if (!customerId || !vendorId || !items || !Array.isArray(items)) {
      return res.status(400).json({ error: "Missing required checkout fields" });
    }
    if (!req.user) {
      return res.status(403).json({ error: `Unauthorized: Invalid JWT token. Details: ${req.jwtError || "Missing token"}` });
    }
    if (req.user.id !== customerId) {
      return res.status(403).json({ error: `Unauthorized: User ID mismatch. Token ID: ${req.user.id}, Expected: ${customerId}` });
    }
    let calculatedTotal = 0;
    const dbProducts = await db.select().from(products).where((0, import_drizzle_orm.eq)(products.vendorId, vendorId));
    for (const item of items) {
      const dbProduct = dbProducts.find((p) => p.id === item.productId);
      if (!dbProduct) {
        return res.status(400).json({ error: `Product ${item.productId} not found` });
      }
      let itemPrice = dbProduct.price;
      if (item.selectedAddons && Array.isArray(item.selectedAddons)) {
        for (const addon of item.selectedAddons) {
          itemPrice += addon.price * (addon.quantity || 1);
        }
      }
      calculatedTotal += itemPrice * item.quantity;
    }
    const finalTotal = calculatedTotal + (serviceFee || 0) + (deliveryFee || 0) + (tax || 0);
    if (paymentMethod === "wallet") {
      const userTransactions = await db.select().from(walletTransactions).where((0, import_drizzle_orm.eq)(walletTransactions.userId, customerId));
      const balance = userTransactions.reduce((acc, tx) => {
        if (tx.status !== "approved") return acc;
        return tx.type === "deposit" || tx.type === "refund" ? acc + tx.amount : acc - tx.amount;
      }, 0);
      if (balance < finalTotal) {
        return res.status(400).json({ error: "Insufficient wallet balance" });
      }
      await db.insert(walletTransactions).values({
        id: Math.random().toString(36).substring(2, 11),
        userId: customerId,
        userName: customerName,
        amount: finalTotal,
        type: "purchase",
        status: "approved",
        createdAt: (/* @__PURE__ */ new Date()).toISOString(),
        note: `Order payment for vendor: ${vendorName}`
      });
    }
    const orderId = Math.random().toString(36).substring(2, 11);
    await db.insert(orders).values({
      id: orderId,
      customerId,
      customerName,
      customerPhone,
      vendorId,
      vendorName,
      status: "pending",
      totalAmount: finalTotal,
      deliveryAddress,
      paymentMethod,
      serviceFee,
      deliveryFee,
      tax,
      createdAt: (/* @__PURE__ */ new Date()).toISOString()
    });
    for (const item of items) {
      await db.insert(orderItems).values({
        id: Math.random().toString(36).substring(2, 11),
        orderId,
        productId: item.productId,
        name: item.name,
        price: item.price,
        // Storing what they paid (we verified it above)
        quantity: item.quantity
      });
    }
    io.to(vendorId).emit("new_order", { orderId, vendorId });
    io.to("admin").emit("new_order", { orderId, vendorId });
    const sendPush = async (targetId, title, message) => {
      try {
        const subs = await db.select().from(pushSubscriptions).where((0, import_drizzle_orm.eq)(pushSubscriptions.userId, targetId));
        for (const sub of subs) {
          try {
            await import_web_push.default.sendNotification({
              endpoint: sub.endpoint,
              keys: { p256dh: sub.p256dh, auth: sub.auth }
            }, JSON.stringify({ title, message }));
          } catch (e) {
            if (e.statusCode === 410 || e.statusCode === 404) {
              await db.delete(pushSubscriptions).where((0, import_drizzle_orm.eq)(pushSubscriptions.id, sub.id));
            }
          }
        }
      } catch (e) {
        console.error("Push failed for", targetId, e);
      }
    };
    sendPush(vendorId, "New Order Received!", `Order #${orderId} for ?${finalTotal.toLocaleString()}`);
    sendPush("admin", "New Platform Order!", `Order #${orderId} placed at ${vendorName}`);
    res.json({ success: true, orderId, finalTotal });
  } catch (error) {
    console.error("Checkout failed:", error);
    res.status(500).json({ error: "Checkout process failed." });
  }
});
app.post("/api/wallet/fund", verifyTokenOptional, async (req, res) => {
  try {
    const { userId, userName, amount, gateway, reference } = req.body;
    if (!req.user || req.user.id !== userId) {
      return res.status(403).json({ error: "Unauthorized: Invalid JWT token or user ID mismatch during wallet funding." });
    }
    if (!userId || !amount || amount <= 0) {
      return res.status(400).json({ error: "Invalid funding request" });
    }
    const isVerified = true;
    if (!isVerified) {
      return res.status(400).json({ error: "Payment verification failed" });
    }
    const txId = Math.random().toString(36).substring(2, 11);
    await db.insert(walletTransactions).values({
      id: txId,
      userId,
      userName,
      amount,
      type: "deposit",
      status: gateway === "bank_transfer" ? "pending" : "approved",
      gateway,
      reference,
      createdAt: (/* @__PURE__ */ new Date()).toISOString(),
      note: `Wallet funding via ${gateway}`
    });
    res.json({ success: true, transactionId: txId });
  } catch (error) {
    console.error("Wallet funding failed:", error);
    res.status(500).json({ error: "Failed to process wallet funding." });
  }
});
app.post("/api/push/subscribe", verifyTokenOptional, async (req, res) => {
  try {
    const { subscription } = req.body;
    if (!req.user || !subscription) return res.status(400).json({ error: "Invalid request" });
    if (req.user.roles?.includes("super_admin")) {
      const adminExists = await db.select().from(pushSubscriptions).where(
        import_drizzle_orm.sql`${pushSubscriptions.userId} = 'admin' AND ${pushSubscriptions.endpoint} = ${subscription.endpoint}`
      );
      if (adminExists.length === 0) {
        await db.insert(pushSubscriptions).values({
          id: Math.random().toString(36).substring(2, 11),
          userId: "admin",
          endpoint: subscription.endpoint,
          p256dh: subscription.keys.p256dh,
          auth: subscription.keys.auth,
          createdAt: (/* @__PURE__ */ new Date()).toISOString()
        });
      }
    }
    const exists = await db.select().from(pushSubscriptions).where(
      import_drizzle_orm.sql`${pushSubscriptions.userId} = ${req.user.id} AND ${pushSubscriptions.endpoint} = ${subscription.endpoint}`
    );
    if (exists.length === 0) {
      await db.insert(pushSubscriptions).values({
        id: Math.random().toString(36).substring(2, 11),
        userId: req.user.id,
        endpoint: subscription.endpoint,
        p256dh: subscription.keys.p256dh,
        auth: subscription.keys.auth,
        createdAt: (/* @__PURE__ */ new Date()).toISOString()
      });
    }
    res.json({ success: true });
  } catch (error) {
    console.error("Push subscribe failed:", error);
    res.status(500).json({ error: "Failed to subscribe." });
  }
});
async function startServer() {
  if (process.env.NODE_ENV !== "production") {
    const vite = await (0, import_vite.createServer)({
      server: { middlewareMode: true },
      appType: "spa"
    });
    app.use(vite.middlewares);
  } else {
    await runMigrations();
    const distPath = import_path2.default.join(process.cwd(), "dist");
    app.use(import_express.default.static(distPath));
    app.get("*", (req, res) => {
      res.sendFile(import_path2.default.join(distPath, "index.html"));
    });
  }
  server.listen(PORT, () => {
    console.log(`Server running on port ${PORT}`);
  });
}
startServer();
//# sourceMappingURL=server.cjs.map
